/**
 * Navbar.jsx — Top navigation bar
 *
 * PROPS:
 *   - darkMode (bool): current dark mode state
 *   - toggleDark (fn): function to toggle dark mode
 *
 * STATE:
 *   - menuOpen (bool): mobile hamburger menu open/close
 *
 * ROUTING: useLocation() to highlight active nav link
 */
import React, { useState, useEffect } from 'react'
import { NavLink, useLocation } from 'react-router-dom'
import { motion, AnimatePresence } from 'framer-motion'

// Nav links data — defined as array for clean map() rendering
const NAV_LINKS = [
  { path: '/', label: 'home', icon: '~' },
  { path: '/about', label: 'about', icon: '>' },
  { path: '/resume', label: 'resume', icon: '#' },
  { path: '/projects', label: 'projects', icon: '{' },
  { path: '/contact', label: 'contact', icon: '@' },
]

export default function Navbar({ darkMode, toggleDark }) {
  // STATE: controls mobile menu visibility
  const [menuOpen, setMenuOpen] = useState(false)
  // STATE: navbar background on scroll
  const [scrolled, setScrolled] = useState(false)

  const location = useLocation()

  // Close menu on route change
  useEffect(() => { setMenuOpen(false) }, [location])

  // Detect scroll to add background blur
  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 20)
    window.addEventListener('scroll', onScroll)
    return () => window.removeEventListener('scroll', onScroll)
  }, [])

  return (
    <nav
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        scrolled
          ? 'bg-cyber-dark/95 backdrop-blur-sm border-b border-neon/20 shadow-neon'
          : 'bg-transparent'
      }`}
    >
      <div className="max-w-6xl mx-auto px-4 sm:px-6">
        <div className="flex items-center justify-between h-16">

          {/* ── Logo / Brand ── */}
          <NavLink to="/" className="group flex items-center gap-2">
            <span className="text-neon font-bold text-lg tracking-wider neon-text-dim group-hover:neon-text transition-all">
              [MB]
            </span>
            <span className="hidden sm:block text-gray-500 text-sm">
              <span className="text-neon/60">./</span>madhav-bhandari
            </span>
          </NavLink>

          {/* ── Desktop Nav Links — rendered with map() ── */}
          <div className="hidden md:flex items-center gap-1">
            {NAV_LINKS.map(({ path, label, icon }) => (
              <NavLink
                key={path}
                to={path}
                end={path === '/'}
                className={({ isActive }) =>
                  `relative px-4 py-2 text-xs tracking-widest uppercase transition-all duration-200 group ${
                    isActive
                      ? 'text-neon neon-text-dim'
                      : 'text-gray-500 hover:text-neon'
                  }`
                }
              >
                {({ isActive }) => (
                  <>
                    {/* Active indicator bar */}
                    {isActive && (
                      <motion.span
                        layoutId="nav-indicator"
                        className="absolute inset-0 border border-neon/30 bg-neon/5"
                        style={{ borderRadius: '2px' }}
                        transition={{ type: 'spring', stiffness: 380, damping: 30 }}
                      />
                    )}
                    <span className="relative z-10">
                      <span className="text-neon/50 mr-1">{icon}</span>
                      {label}
                    </span>
                  </>
                )}
              </NavLink>
            ))}
          </div>

          {/* ── Right controls ── */}
          <div className="flex items-center gap-3">
            {/* Dark mode toggle */}
            <button
              onClick={toggleDark}
              title="Toggle theme"
              className="hidden md:flex items-center justify-center w-8 h-8 border border-neon/30 text-neon/60 hover:text-neon hover:border-neon/60 transition-all text-xs"
              aria-label="Toggle dark mode"
            >
              {darkMode ? '◐' : '○'}
            </button>

            {/* Mobile hamburger */}
            <button
              onClick={() => setMenuOpen(prev => !prev)}
              className="md:hidden flex flex-col gap-1.5 p-2 group"
              aria-label="Toggle menu"
            >
              <span className={`block w-5 h-px bg-neon transition-all duration-300 ${menuOpen ? 'rotate-45 translate-y-2' : ''}`} />
              <span className={`block w-5 h-px bg-neon transition-all duration-300 ${menuOpen ? 'opacity-0' : ''}`} />
              <span className={`block w-5 h-px bg-neon transition-all duration-300 ${menuOpen ? '-rotate-45 -translate-y-2' : ''}`} />
            </button>
          </div>
        </div>

        {/* ── Mobile Menu ── */}
        <AnimatePresence>
          {menuOpen && (
            <motion.div
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: 'auto' }}
              exit={{ opacity: 0, height: 0 }}
              transition={{ duration: 0.2 }}
              className="md:hidden overflow-hidden border-t border-neon/20 bg-cyber-dark/98"
            >
              <div className="py-3 space-y-1">
                {NAV_LINKS.map(({ path, label, icon }) => (
                  <NavLink
                    key={path}
                    to={path}
                    end={path === '/'}
                    className={({ isActive }) =>
                      `flex items-center gap-3 px-4 py-3 text-sm tracking-wider transition-colors ${
                        isActive
                          ? 'text-neon bg-neon/5 border-l-2 border-neon'
                          : 'text-gray-500 hover:text-neon hover:bg-neon/5'
                      }`
                    }
                  >
                    <span className="text-neon/60 w-4">{icon}</span>
                    <span className="uppercase text-xs tracking-widest">{label}</span>
                  </NavLink>
                ))}
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      {/* Bottom glow line */}
      <div className="h-px bg-gradient-to-r from-transparent via-neon/30 to-transparent" />
    </nav>
  )
}
