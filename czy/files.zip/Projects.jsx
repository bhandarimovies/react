/**
 * Projects.jsx — Projects showcase page
 *
 * STATE: filter (string) — active category filter
 * PROPS passed DOWN: project data is passed to <ProjectCard> as props
 * Uses map() for list rendering and conditional filtering
 */
import React, { useState } from 'react'
import { motion } from 'framer-motion'
import ProjectCard from '../components/ProjectCard.jsx'

const pageVariants = {
  initial: { opacity: 0, y: 20 },
  animate: { opacity: 1, y: 0, transition: { duration: 0.5 } },
  exit: { opacity: 0, y: -20, transition: { duration: 0.3 } },
}

/**
 * PROJECTS DATA — passed as props to ProjectCard components
 * In a larger app, this would come from an API or CMS
 */
const PROJECTS = [
  {
    id: 1,
    title: 'Tic Tac Toe Game',
    description:
      'A fully functional browser-based Tic Tac Toe game with two-player mode, win detection, and score tracking. Built with vanilla JavaScript and DOM manipulation.',
    tags: ['JavaScript', 'HTML5', 'CSS3', 'DOM API'],
    type: 'Game',
    icon: '🎮',
    link: null,
    highlights: [
      'Two-player local multiplayer support',
      'Real-time win/draw detection algorithm',
      'Animated game board with smooth transitions',
      'Score tracking across multiple rounds',
    ],
    category: 'Web Dev',
  },
  {
    id: 2,
    title: 'Women\'s NGO Website',
    description:
      'A complete informational website built for a local women\'s NGO in Sikkim. Includes organization overview, event listings, donation info, and contact form.',
    tags: ['HTML', 'CSS', 'JavaScript', 'Responsive Design'],
    type: 'Social Good',
    icon: '🌸',
    link: null,
    highlights: [
      'Fully responsive for mobile and desktop',
      'Accessibility-first design approach',
      'Custom CSS animations and hover effects',
      'Pro-bono project for community impact',
    ],
    category: 'Web Dev',
  },
  {
    id: 3,
    title: 'Web App Vulnerability Assessment',
    description:
      'A structured security audit of a web application to identify and document vulnerabilities including XSS, CSRF, SQL Injection, and broken authentication.',
    tags: ['Burp Suite', 'OWASP', 'Kali Linux', 'Security Testing'],
    type: 'Security',
    icon: '🔐',
    link: null,
    highlights: [
      'Identified 8+ critical and medium vulnerabilities',
      'Documented attack vectors with CVSS scoring',
      'Followed OWASP Testing Guide methodology',
      'Produced professional pentest report with remediation steps',
    ],
    category: 'Security',
  },
  {
    id: 4,
    title: 'MFA Bypass Analysis',
    description:
      'Academic research into multi-factor authentication bypass techniques including OTP interception, SIM swapping, and TOTP token manipulation in test environments.',
    tags: ['Security Research', 'MFA', 'TOTP', 'Authentication'],
    type: 'Security',
    icon: '🛡️',
    link: null,
    highlights: [
      'Analyzed 5+ common MFA bypass techniques',
      'Tested in isolated, authorized lab environment',
      'Proposed hardened MFA implementation guidelines',
      'Cited NIST SP 800-63B standards in findings',
    ],
    category: 'Security',
  },
]

// Filter categories derived from project data
const CATEGORIES = ['All', 'Web Dev', 'Security']

export default function Projects() {
  // STATE: currently selected filter category
  const [filter, setFilter] = useState('All')

  // CONDITIONAL: filter projects based on selected category
  const filteredProjects = filter === 'All'
    ? PROJECTS
    : PROJECTS.filter(p => p.category === filter)

  return (
    <motion.div
      variants={pageVariants}
      initial="initial"
      animate="animate"
      exit="exit"
      className="page-wrapper"
    >
      <div className="max-w-5xl mx-auto px-4 sm:px-6 py-16">

        {/* Page header */}
        <motion.div
          initial={{ opacity: 0, x: -30 }}
          animate={{ opacity: 1, x: 0 }}
          className="mb-8"
        >
          <p className="text-xs text-gray-600 mb-2 terminal-prompt">ls ./projects/</p>
          <h1 className="text-3xl md:text-4xl font-bold text-gray-100 section-title">
            Projects
          </h1>
          <p className="mt-4 text-gray-500 text-sm">
            <span className="text-neon/60">{filteredProjects.length}</span>
            <span className="text-gray-700"> / {PROJECTS.length}</span>
            <span className="text-gray-600"> projects loaded</span>
          </p>
        </motion.div>

        {/* ── Filter Buttons ── */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.2 }}
          className="flex flex-wrap gap-2 mb-8"
        >
          {/* List rendering for filter buttons */}
          {CATEGORIES.map(cat => (
            <button
              key={cat}
              onClick={() => setFilter(cat)}
              className={`px-4 py-1.5 text-xs tracking-widest uppercase transition-all border ${
                filter === cat
                  ? 'border-neon text-neon bg-neon/10 shadow-neon'
                  : 'border-neon/20 text-gray-500 hover:border-neon/40 hover:text-gray-300'
              }`}
            >
              {cat === 'All' ? `[${cat}]` : cat}
            </button>
          ))}
        </motion.div>

        {/* ── Projects Grid — dynamic rendering with map() ── */}
        <motion.div
          layout
          className="grid sm:grid-cols-2 gap-4"
        >
          {filteredProjects.map((project, index) => (
            /**
             * Each project is passed as a PROP to ProjectCard
             * index is passed for staggered animation delay
             */
            <ProjectCard
              key={project.id}
              project={project}
              index={index}
            />
          ))}
        </motion.div>

        {/* Empty state — conditional rendering */}
        {filteredProjects.length === 0 && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="text-center py-16 text-gray-600"
          >
            <p className="text-3xl mb-4">◎</p>
            <p className="text-sm">No projects found in this category.</p>
          </motion.div>
        )}

        {/* ── CTA at bottom ── */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="mt-12 cyber-card p-6 text-center"
        >
          <p className="text-neon/50 text-xs mb-2">// more.coming.soon</p>
          <h3 className="text-gray-300 font-medium mb-2">More projects in the pipeline</h3>
          <p className="text-gray-600 text-sm">
            Currently working on a full-stack security dashboard and a CTF writeup blog.
          </p>
          <a
            href="https://github.com/"
            target="_blank"
            rel="noopener noreferrer"
            className="btn-neon mt-4 inline-flex text-xs"
          >
            ↗ view github
          </a>
        </motion.div>
      </div>
    </motion.div>
  )
}
