/**
 * Contact.jsx — Contact form page
 *
 * STATE:
 *   - formData (object): { name, email, message } — controlled inputs
 *   - errors (object): validation error messages
 *   - status (string): 'idle' | 'sending' | 'success' | 'error'
 *
 * EMAILJS: Replace SERVICE_ID, TEMPLATE_ID, PUBLIC_KEY with your own
 * Get them from: https://www.emailjs.com/
 */
import React, { useState, useRef } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import emailjs from '@emailjs/browser'

const pageVariants = {
  initial: { opacity: 0, y: 20 },
  animate: { opacity: 1, y: 0, transition: { duration: 0.5 } },
  exit: { opacity: 0, y: -20, transition: { duration: 0.3 } },
}

// ── EmailJS Configuration ──
// Replace with your own credentials from emailjs.com
const EMAILJS_CONFIG = {
  SERVICE_ID: 'your_service_id',      // e.g. 'service_abc123'
  TEMPLATE_ID: 'your_template_id',    // e.g. 'template_xyz789'
  PUBLIC_KEY: 'your_public_key',      // e.g. 'user_Abc123XYZ'
}

// Social / contact info items
const CONTACT_INFO = [
  { label: 'Email', value: 'madhav@example.com', icon: '@', href: 'mailto:madhav@example.com' },
  { label: 'GitHub', value: 'github.com/madhav', icon: '⬡', href: 'https://github.com/' },
  { label: 'LinkedIn', value: 'linkedin.com/in/madhav', icon: '◈', href: 'https://linkedin.com/' },
  { label: 'Location', value: 'Sikkim, India', icon: '◎', href: null },
]

// Simple validators
function validateForm(data) {
  const errs = {}
  if (!data.name.trim()) errs.name = 'Name is required'
  else if (data.name.trim().length < 2) errs.name = 'Name too short'

  if (!data.email.trim()) errs.email = 'Email is required'
  else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(data.email)) errs.email = 'Invalid email format'

  if (!data.message.trim()) errs.message = 'Message is required'
  else if (data.message.trim().length < 10) errs.message = 'Message too short (min 10 chars)'

  return errs
}

export default function Contact() {
  const formRef = useRef(null)

  // STATE: form field values
  const [formData, setFormData] = useState({ name: '', email: '', message: '' })
  // STATE: validation errors per field
  const [errors, setErrors] = useState({})
  // STATE: submission status
  const [status, setStatus] = useState('idle') // 'idle' | 'sending' | 'success' | 'error'

  // Controlled input handler — updates formData state
  const handleChange = (e) => {
    const { name, value } = e.target
    setFormData(prev => ({ ...prev, [name]: value }))
    // Clear error on change
    if (errors[name]) setErrors(prev => ({ ...prev, [name]: '' }))
  }

  // Form submission
  const handleSubmit = async (e) => {
    e.preventDefault()

    // Validate inputs
    const validationErrors = validateForm(formData)
    if (Object.keys(validationErrors).length > 0) {
      setErrors(validationErrors)
      return
    }

    setStatus('sending')

    try {
      // Send via EmailJS
      await emailjs.sendForm(
        EMAILJS_CONFIG.SERVICE_ID,
        EMAILJS_CONFIG.TEMPLATE_ID,
        formRef.current,
        EMAILJS_CONFIG.PUBLIC_KEY
      )
      setStatus('success')
      setFormData({ name: '', email: '', message: '' })
    } catch (err) {
      console.error('EmailJS error:', err)
      setStatus('error')
    }
  }

  const resetForm = () => {
    setStatus('idle')
    setErrors({})
  }

  return (
    <motion.div
      variants={pageVariants}
      initial="initial"
      animate="animate"
      exit="exit"
      className="page-wrapper"
    >
      <div className="max-w-5xl mx-auto px-4 sm:px-6 py-16">

        {/* Page header */}
        <motion.div
          initial={{ opacity: 0, x: -30 }}
          animate={{ opacity: 1, x: 0 }}
          className="mb-12"
        >
          <p className="text-xs text-gray-600 mb-2 terminal-prompt">./send-message.sh</p>
          <h1 className="text-3xl md:text-4xl font-bold text-gray-100 section-title">
            Contact
          </h1>
          <p className="mt-4 text-gray-500 text-sm max-w-xl">
            Have a project idea, security question, or just want to connect?
            Drop a message — I respond within 24 hours.
          </p>
        </motion.div>

        <div className="grid md:grid-cols-5 gap-8">

          {/* ── Left: Contact Info ── */}
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.2 }}
            className="md:col-span-2 space-y-4"
          >
            <div className="cyber-card p-5">
              <p className="text-xs text-neon/50 mb-4">// reach_me_at</p>
              <div className="space-y-3">
                {/* List rendering */}
                {CONTACT_INFO.map(({ label, value, icon, href }) => (
                  <div key={label} className="flex items-start gap-3 group">
                    <span className="text-neon/40 text-sm mt-0.5 group-hover:text-neon transition-colors">
                      {icon}
                    </span>
                    <div>
                      <p className="text-gray-600 text-xs">{label}</p>
                      {href ? (
                        <a
                          href={href}
                          target={href.startsWith('http') ? '_blank' : undefined}
                          rel="noopener noreferrer"
                          className="text-gray-400 text-xs hover:text-neon transition-colors"
                        >
                          {value}
                        </a>
                      ) : (
                        <p className="text-gray-400 text-xs">{value}</p>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Availability badge */}
            <div className="cyber-card p-5">
              <div className="flex items-center gap-2 mb-3">
                <span className="w-2 h-2 rounded-full bg-neon animate-pulse" />
                <span className="text-neon text-xs font-medium">Available for Work</span>
              </div>
              <p className="text-gray-500 text-xs leading-relaxed">
                Currently seeking internship opportunities in web development
                or cybersecurity. Open to remote and on-site roles.
              </p>
            </div>

            {/* Fun terminal block */}
            <div className="cyber-card p-5 text-xs text-gray-600">
              <p className="text-neon/40 mb-2"># response_time</p>
              <p className="terminal-prompt">avg response: ~24h</p>
              <p className="terminal-prompt">timezone: IST (UTC+5:30)</p>
              <p className="terminal-prompt">preferred: email/linkedin</p>
            </div>
          </motion.div>

          {/* ── Right: Contact Form ── */}
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.3 }}
            className="md:col-span-3"
          >
            <div className="cyber-card p-6 relative corner-tl corner-br">
              <p className="text-xs text-neon/50 mb-6">// compose_message.exe</p>

              {/* ── Success State — conditional rendering ── */}
              <AnimatePresence mode="wait">
                {status === 'success' ? (
                  <motion.div
                    key="success"
                    initial={{ opacity: 0, scale: 0.95 }}
                    animate={{ opacity: 1, scale: 1 }}
                    exit={{ opacity: 0 }}
                    className="text-center py-12"
                  >
                    <div className="text-5xl mb-4">✓</div>
                    <h3 className="text-neon text-lg font-bold mb-2">Message Transmitted!</h3>
                    <p className="text-gray-500 text-sm mb-6">
                      Your message has been sent successfully. I'll get back to you soon.
                    </p>
                    <button onClick={resetForm} className="btn-neon text-xs">
                      ↺ send another
                    </button>
                  </motion.div>
                ) : (
                  <motion.form
                    key="form"
                    ref={formRef}
                    onSubmit={handleSubmit}
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    exit={{ opacity: 0 }}
                    className="space-y-5"
                    noValidate
                  >
                    {/* Name field */}
                    <div>
                      <label className="block text-xs text-gray-500 mb-1.5">
                        <span className="text-neon/40 mr-1">$</span> name *
                      </label>
                      <input
                        type="text"
                        name="name"
                        value={formData.name}
                        onChange={handleChange}
                        placeholder="Your full name"
                        className={`w-full bg-cyber-dark border text-gray-300 text-sm px-3 py-2.5 outline-none transition-colors font-mono placeholder:text-gray-700 focus:border-neon/50 ${
                          errors.name ? 'border-red-500/50' : 'border-neon/20'
                        }`}
                        disabled={status === 'sending'}
                      />
                      {/* Conditional: show error if present */}
                      {errors.name && (
                        <p className="text-red-400 text-xs mt-1">⚠ {errors.name}</p>
                      )}
                    </div>

                    {/* Email field */}
                    <div>
                      <label className="block text-xs text-gray-500 mb-1.5">
                        <span className="text-neon/40 mr-1">$</span> email *
                      </label>
                      <input
                        type="email"
                        name="email"
                        value={formData.email}
                        onChange={handleChange}
                        placeholder="your@email.com"
                        className={`w-full bg-cyber-dark border text-gray-300 text-sm px-3 py-2.5 outline-none transition-colors font-mono placeholder:text-gray-700 focus:border-neon/50 ${
                          errors.email ? 'border-red-500/50' : 'border-neon/20'
                        }`}
                        disabled={status === 'sending'}
                      />
                      {errors.email && (
                        <p className="text-red-400 text-xs mt-1">⚠ {errors.email}</p>
                      )}
                    </div>

                    {/* Message field */}
                    <div>
                      <label className="block text-xs text-gray-500 mb-1.5">
                        <span className="text-neon/40 mr-1">$</span> message *
                      </label>
                      <textarea
                        name="message"
                        value={formData.message}
                        onChange={handleChange}
                        rows={5}
                        placeholder="Write your message here..."
                        className={`w-full bg-cyber-dark border text-gray-300 text-sm px-3 py-2.5 outline-none transition-colors font-mono placeholder:text-gray-700 focus:border-neon/50 resize-none ${
                          errors.message ? 'border-red-500/50' : 'border-neon/20'
                        }`}
                        disabled={status === 'sending'}
                      />
                      <div className="flex justify-between mt-1">
                        {errors.message && (
                          <p className="text-red-400 text-xs">⚠ {errors.message}</p>
                        )}
                        <p className="text-gray-700 text-xs ml-auto">
                          {formData.message.length} chars
                        </p>
                      </div>
                    </div>

                    {/* Error status message */}
                    {status === 'error' && (
                      <div className="border border-red-500/30 bg-red-500/5 p-3 text-xs text-red-400">
                        ⚠ Failed to send message. Please check your EmailJS configuration or try again.
                      </div>
                    )}

                    {/* Submit button */}
                    <button
                      type="submit"
                      disabled={status === 'sending'}
                      className={`btn-neon w-full justify-center text-xs ${
                        status === 'sending' ? 'opacity-60 cursor-not-allowed' : ''
                      }`}
                    >
                      {status === 'sending' ? (
                        <>
                          <span className="animate-spin">◌</span> transmitting...
                        </>
                      ) : (
                        <>
                          <span>→</span> send message
                        </>
                      )}
                    </button>
                  </motion.form>
                )}
              </AnimatePresence>
            </div>
          </motion.div>
        </div>
      </div>
    </motion.div>
  )
}
