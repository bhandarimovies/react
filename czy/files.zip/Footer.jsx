/**
 * Footer.jsx — Site footer
 * No props or complex state — purely presentational
 */
import React from 'react'
import { NavLink } from 'react-router-dom'

const SOCIAL_LINKS = [
  { label: 'GitHub', icon: 'gh', href: 'https://github.com/' },
  { label: 'LinkedIn', icon: 'in', href: 'https://linkedin.com/' },
  { label: 'Twitter', icon: 'tw', href: 'https://twitter.com/' },
]

export default function Footer() {
  const year = new Date().getFullYear()

  return (
    <footer className="relative border-t border-neon/10 bg-cyber-dark">
      {/* Top glow line */}
      <div className="h-px bg-gradient-to-r from-transparent via-neon/20 to-transparent" />

      <div className="max-w-6xl mx-auto px-4 sm:px-6 py-8">
        <div className="flex flex-col md:flex-row items-center justify-between gap-4">

          {/* Brand */}
          <div className="flex items-center gap-3">
            <span className="text-neon font-bold tracking-wider neon-text-dim">[MB]</span>
            <span className="text-gray-600 text-xs">Madhav Bhandari</span>
          </div>

          {/* Status indicator */}
          <div className="flex items-center gap-2 text-xs text-gray-600">
            <span className="inline-block w-2 h-2 rounded-full bg-neon animate-pulse" />
            <span className="terminal-prompt">system online — all processes nominal</span>
          </div>

          {/* Social links */}
          <div className="flex items-center gap-2">
            {SOCIAL_LINKS.map(({ label, icon, href }) => (
              <a
                key={label}
                href={href}
                target="_blank"
                rel="noopener noreferrer"
                title={label}
                className="w-8 h-8 flex items-center justify-center border border-neon/20 text-gray-500 hover:text-neon hover:border-neon/50 text-xs transition-all duration-200 hover:shadow-neon"
              >
                {icon}
              </a>
            ))}
          </div>
        </div>

        {/* Bottom copyright */}
        <div className="mt-6 pt-4 border-t border-neon/5 text-center text-xs text-gray-700">
          <span className="text-neon/30">©</span> {year} <span className="text-gray-600">Madhav Bhandari</span>
          <span className="text-gray-700 mx-2">·</span>
          <span className="text-gray-700">Built with React + Vite</span>
          <span className="text-gray-700 mx-2">·</span>
          <span className="text-neon/40">// stay curious. stay secure.</span>
        </div>
      </div>
    </footer>
  )
}
